let posts=[]; let filter='all'; let currentUser=null;
const $=s=>document.querySelector(s);
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function showToast(t){const e=$('#toast');e.textContent=t;e.classList.add('show');setTimeout(()=>e.classList.remove('show'),2200)}
async function api(path,opts={}){const r=await fetch(path,{credentials:'same-origin',headers:{'content-type':'application/json',...(opts.headers||{})},...opts});let d={};try{d=await r.json()}catch{}if(!r.ok)throw new Error(d.error||'Request failed');return d}
async function loadMe(){const d=await api('/api/me');currentUser=d.user;renderAuth()}
function renderAuth(){let b=$('#authBtn');if(!b)return;b.textContent=currentUser?`Hi, ${currentUser.display_name}`:'Login';b.onclick=()=>currentUser?logout():openAuth()}
async function loadPosts(){const q=encodeURIComponent($('#search')?.value||'');const cat=filter==='all'?'all':filter;const d=await api(`/api/posts?category=${cat}&q=${q}`);posts=d.posts;renderFeed();}
function renderFeed(){const arr=posts;$('#feed').innerHTML=arr.length?arr.map(s=>`<article class="story"><div class="story-top"><div class="avatar">${esc((s.author||'SS').split(' ').map(x=>x[0]).slice(0,2).join(''))}</div><div><b>${esc(s.author)}</b><br><small>${new Date(s.created_at*1000).toLocaleString()} • ${esc(s.tag)}</small></div></div><h3>${esc(s.title)}</h3><p>${esc(s.body)}</p><div class="story-actions"><button onclick="react('${s.id}',this)">♥ ${s.likes}</button><button onclick="comment('${s.id}')">💬 ${s.comments}</button><button onclick="save('${s.id}')">🔖 ${s.saved?'Saved':'Save'}</button><button onclick="shareStory('${s.id}')">↗ Share</button></div></article>`).join(''):`<div class="empty">No stories found.</div>`}
function setFilter(f){filter=f;document.querySelectorAll('.filter').forEach(b=>b.classList.toggle('active',b.dataset.filter===f));loadPosts()}
async function react(id,b){try{const d=await api(`/api/posts/${id}/like`,{method:'POST'});b.textContent=`♥ ${d.likes}`;b.classList.toggle('active',d.liked)}catch(e){showToast(e.message)}}
async function save(id){try{const d=await api(`/api/posts/${id}/save`,{method:'POST'});showToast(d.saved?'Saved for later':'Removed from saved');await loadPosts()}catch(e){showToast(e.message)}}
async function comment(id){if(!currentUser)return openAuth();const c=prompt('Write your comment:');if(!c?.trim())return;try{await api(`/api/posts/${id}/comments`,{method:'POST',body:JSON.stringify({body:c})});showToast('Comment posted');await loadPosts()}catch(e){showToast(e.message)}}
async function shareStory(id){const s=posts.find(x=>x.id===id);if(!s)return;if(navigator.share)await navigator.share({title:s.title,text:s.body,url:location.href});else{await navigator.clipboard?.writeText(s.title);showToast('Story title copied')}}
function runSearch(){loadPosts();$('#feed').scrollIntoView({behavior:'smooth',block:'start'})}
function searchTopic(t){$('#search').value=t;runSearch()}
function scrollToFeed(){$('#feed').scrollIntoView({behavior:'smooth'})}
function openComposer(){if(!currentUser)return openAuth();$('#composer').classList.add('show')}
function closeComposer(){$('#composer').classList.remove('show')}
async function createPost(){const title=$('#postTitle').value.trim(),body=$('#postBody').value.trim(),cat=$('#postCategory').value.toLowerCase();if(!title||!body)return showToast('Add a title and message');try{await api('/api/posts',{method:'POST',body:JSON.stringify({title,body,category:cat})});closeComposer();$('#postTitle').value='';$('#postBody').value='';showToast('Post published');await loadPosts()}catch(e){showToast(e.message)}}
async function subscribe(){const input=document.querySelector('aside .side-card input');try{await api('/api/newsletter',{method:'POST',body:JSON.stringify({email:input.value})});input.value='';showToast('Subscribed — thank you')}catch(e){showToast(e.message)}}
function openAuth(){ $('#authModal').classList.add('show'); $('#authEmail').focus() }
function closeAuth(){ $('#authModal').classList.remove('show') }
async function submitAuth(){const mode=$('#authMode').value,email=$('#authEmail').value.trim(),password=$('#authPassword').value,name=$('#authName').value.trim();try{const d=await api(mode==='login'?'/api/auth/login':'/api/auth/register',{method:'POST',body:JSON.stringify(mode==='login'?{email,password}:{email,password,display_name:name})});currentUser=d.user;closeAuth();renderAuth();showToast(mode==='login'?'Logged in':'Account created');}catch(e){showToast(e.message)}}
async function logout(){await api('/api/auth/logout',{method:'POST'});currentUser=null;renderAuth();showToast('Logged out')}
function toggleAuthMode(){const s=$('#authMode');s.value=s.value==='login'?'register':'login';$('#authNameWrap').style.display=s.value==='register'?'block':'none';$('#authSubmit').textContent=s.value==='register'?'Create account':'Login';$('#authSwitch').textContent=s.value==='register'?'Already have an account? Login':'New here? Create an account'}
document.querySelectorAll('.filter').forEach(b=>b.onclick=()=>setFilter(b.dataset.filter));
$('#menuBtn').onclick=()=>$('#nav').classList.toggle('open');
$('#themeBtn').onclick=()=>{document.documentElement.classList.toggle('light');localStorage.setItem('ss-theme',document.documentElement.classList.contains('light')?'light':'dark')};
if(localStorage.getItem('ss-theme')==='light')document.documentElement.classList.add('light');
$('#search').addEventListener('input',()=>loadPosts());
loadMe().then(loadPosts).catch(()=>loadPosts());
