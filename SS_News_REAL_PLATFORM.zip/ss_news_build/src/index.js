const SESSION_DAYS = 30;
const PBKDF2_ITERATIONS = 210000;
const encoder = new TextEncoder();

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" }
  });
}
function now() { return Math.floor(Date.now() / 1000); }
function id() { return crypto.randomUUID(); }
function bytesToB64(bytes) { let s = ""; for (const b of bytes) s += String.fromCharCode(b); return btoa(s); }
function b64ToBytes(s) { const bin = atob(s); return Uint8Array.from(bin, c => c.charCodeAt(0)); }
async function sha256(text) { const d = await crypto.subtle.digest("SHA-256", encoder.encode(text)); return bytesToB64(new Uint8Array(d)); }
async function passwordHash(password, saltB64) {
  const key = await crypto.subtle.importKey("raw", encoder.encode(password), "PBKDF2", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits({ name: "PBKDF2", salt: b64ToBytes(saltB64), iterations: PBKDF2_ITERATIONS, hash: "SHA-256" }, key, 256);
  return bytesToB64(new Uint8Array(bits));
}
function cookieValue(request, name) {
  const raw = request.headers.get("Cookie") || "";
  const item = raw.split(";").map(x => x.trim()).find(x => x.startsWith(name + "="));
  return item ? decodeURIComponent(item.slice(name.length + 1)) : null;
}
function setCookie(token) {
  return `ss_session=${encodeURIComponent(token)}; Max-Age=${SESSION_DAYS * 86400}; Path=/; HttpOnly; Secure; SameSite=Lax`;
}
function clearCookie() { return "ss_session=; Max-Age=0; Path=/; HttpOnly; Secure; SameSite=Lax"; }
function sameOrigin(request) {
  const origin = request.headers.get("Origin");
  if (!origin) return true;
  return origin === new URL(request.url).origin;
}
async function body(request) { try { return await request.json(); } catch { return null; } }
async function auth(request, env) {
  const token = cookieValue(request, "ss_session");
  if (!token) return null;
  const hash = await sha256(token);
  return await env.DB.prepare(`SELECT u.id,u.email,u.display_name,u.bio,u.avatar_url,u.role FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=? AND s.expires_at>?`).bind(hash, now()).first();
}
function cleanText(value, max) { return String(value ?? "").trim().slice(0, max); }
function validEmail(email) { return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email); }
function publicUser(row) { return row ? { id: row.id, email: row.email, display_name: row.display_name, bio: row.bio, avatar_url: row.avatar_url, role: row.role } : null; }

async function getPosts(request, env) {
  const u = new URL(request.url);
  const category = u.searchParams.get("category") || "all";
  const q = cleanText(u.searchParams.get("q"), 100).toLowerCase();
  const limit = Math.min(Math.max(Number(u.searchParams.get("limit") || 30), 1), 50);
  let sql = `SELECT p.id,p.category,p.tag,p.title,p.body,p.image_url,p.created_at,p.author_id,COALESCE(u.display_name,'SS Desk') author,
    (SELECT COUNT(*) FROM likes l WHERE l.post_id=p.id) likes,
    (SELECT COUNT(*) FROM comments c WHERE c.post_id=p.id AND c.status='published') comments
    FROM posts p LEFT JOIN users u ON u.id=p.author_id WHERE p.status='published'`;
  const params = [];
  if (category !== "all") { sql += " AND p.category=?"; params.push(category); }
  if (q) { sql += " AND lower(p.title || ' ' || p.body || ' ' || COALESCE(u.display_name,'')) LIKE ?"; params.push(`%${q}%`); }
  sql += " ORDER BY p.created_at DESC LIMIT ?"; params.push(limit);
  const rows = await env.DB.prepare(sql).bind(...params).all();
  const user = await auth(request, env);
  let saved = new Set(), liked = new Set();
  if (user) {
    const [s, l] = await Promise.all([
      env.DB.prepare("SELECT post_id FROM saves WHERE user_id=?").bind(user.id).all(),
      env.DB.prepare("SELECT post_id FROM likes WHERE user_id=?").bind(user.id).all()
    ]);
    saved = new Set(s.results.map(x => x.post_id)); liked = new Set(l.results.map(x => x.post_id));
  }
  return json({ posts: rows.results.map(p => ({ ...p, saved: saved.has(p.id), liked: liked.has(p.id) })) });
}

async function register(request, env) {
  if (!sameOrigin(request)) return json({ error: "Invalid origin" }, 403);
  const b = await body(request); const email = cleanText(b?.email, 160).toLowerCase();
  const password = String(b?.password || ""); const display = cleanText(b?.display_name, 60);
  if (!validEmail(email) || password.length < 10 || !display) return json({ error: "Use a valid email, a display name, and a password of at least 10 characters." }, 400);
  const exists = await env.DB.prepare("SELECT id FROM users WHERE email=?").bind(email).first();
  if (exists) return json({ error: "An account with that email already exists." }, 409);
  const salt = crypto.getRandomValues(new Uint8Array(16)); const saltB64 = bytesToB64(salt);
  const hash = await passwordHash(password, saltB64); const uid = id(); const t = now();
  await env.DB.prepare("INSERT INTO users(id,email,password_hash,password_salt,display_name,created_at,updated_at) VALUES(?,?,?,?,?,?,?)").bind(uid,email,hash,saltB64,display,t,t).run();
  const token = id() + id(); const tokenHash = await sha256(token);
  await env.DB.prepare("INSERT INTO sessions(id,user_id,token_hash,expires_at,created_at) VALUES(?,?,?,?,?)").bind(id(),uid,tokenHash,t+SESSION_DAYS*86400,t).run();
  return new Response(JSON.stringify({ user: { id: uid, email, display_name: display, bio: "", avatar_url: "", role: "user" } }), { status: 201, headers: { "content-type":"application/json", "cache-control":"no-store", "Set-Cookie": setCookie(token) } });
}

async function login(request, env) {
  if (!sameOrigin(request)) return json({ error: "Invalid origin" }, 403);
  const b = await body(request); const email = cleanText(b?.email, 160).toLowerCase(); const password = String(b?.password || "");
  const user = await env.DB.prepare("SELECT * FROM users WHERE email=?").bind(email).first();
  if (!user) return json({ error: "Invalid email or password." }, 401);
  const hash = await passwordHash(password, user.password_salt);
  if (hash !== user.password_hash) return json({ error: "Invalid email or password." }, 401);
  const token = id() + id(); const t=now();
  await env.DB.prepare("INSERT INTO sessions(id,user_id,token_hash,expires_at,created_at) VALUES(?,?,?,?,?)").bind(id(),user.id,await sha256(token),t+SESSION_DAYS*86400,t).run();
  return new Response(JSON.stringify({ user: publicUser(user) }), { headers: { "content-type":"application/json", "cache-control":"no-store", "Set-Cookie": setCookie(token) } });
}

async function logout(request, env) {
  const token = cookieValue(request, "ss_session"); if (token) await env.DB.prepare("DELETE FROM sessions WHERE token_hash=?").bind(await sha256(token)).run();
  return new Response(JSON.stringify({ ok:true }), { headers: { "content-type":"application/json", "Set-Cookie": clearCookie() } });
}

async function createPost(request, env) {
  if (!sameOrigin(request)) return json({ error: "Invalid origin" }, 403);
  const user = await auth(request, env); if (!user) return json({ error:"Login required" },401);
  const b=await body(request); const title=cleanText(b?.title,180), text=cleanText(b?.body,5000), category=cleanText(b?.category,20).toLowerCase();
  if (!title || !text || !["news","tech","sport","world","education","business","entertainment"].includes(category)) return json({error:"Invalid post data"},400);
  const pid=id(), t=now();
  await env.DB.prepare("INSERT INTO posts(id,author_id,category,tag,title,body,status,created_at,updated_at) VALUES(?,?,?,?,?,?,?, ?,?)").bind(pid,user.id,category,"COMMUNITY",title,text,"published",t,t).run();
  return json({ post:{id:pid,title,body:text,category,author:user.display_name,likes:0,comments:0,saved:false,liked:false,created_at:t} },201);
}

async function toggleLike(request, env, postId) {
  const user=await auth(request,env); if(!user)return json({error:"Login required"},401);
  const p=await env.DB.prepare("SELECT id FROM posts WHERE id=? AND status='published'").bind(postId).first(); if(!p)return json({error:"Post not found"},404);
  const old=await env.DB.prepare("SELECT 1 FROM likes WHERE user_id=? AND post_id=?").bind(user.id,postId).first();
  if(old) await env.DB.prepare("DELETE FROM likes WHERE user_id=? AND post_id=?").bind(user.id,postId).run(); else await env.DB.prepare("INSERT INTO likes(user_id,post_id,created_at) VALUES(?,?,?)").bind(user.id,postId,now()).run();
  const count=await env.DB.prepare("SELECT COUNT(*) n FROM likes WHERE post_id=?").bind(postId).first();
  return json({liked:!old,likes:Number(count.n)});
}
async function toggleSave(request, env, postId) {
  const user=await auth(request,env); if(!user)return json({error:"Login required"},401);
  const old=await env.DB.prepare("SELECT 1 FROM saves WHERE user_id=? AND post_id=?").bind(user.id,postId).first();
  if(old) await env.DB.prepare("DELETE FROM saves WHERE user_id=? AND post_id=?").bind(user.id,postId).run(); else await env.DB.prepare("INSERT INTO saves(user_id,post_id,created_at) VALUES(?,?,?)").bind(user.id,postId,now()).run();
  return json({saved:!old});
}
async function comments(request, env, postId) {
  if(request.method==="GET") {
    const r=await env.DB.prepare(`SELECT c.id,c.body,c.created_at,COALESCE(u.display_name,'Deleted user') author FROM comments c LEFT JOIN users u ON u.id=c.user_id WHERE c.post_id=? AND c.status='published' ORDER BY c.created_at DESC`).bind(postId).all();
    return json({comments:r.results});
  }
  if(!sameOrigin(request))return json({error:"Invalid origin"},403);
  const user=await auth(request,env); if(!user)return json({error:"Login required"},401); const b=await body(request); const text=cleanText(b?.body,1000); if(!text)return json({error:"Comment cannot be empty"},400);
  const cid=id(); await env.DB.prepare("INSERT INTO comments(id,user_id,post_id,body,created_at) VALUES(?,?,?,?,?)").bind(cid,user.id,postId,text,now()).run(); return json({comment:{id:cid,body:text,author:user.display_name,created_at:now()}},201);
}
async function saved(request,env){const user=await auth(request,env);if(!user)return json({error:"Login required"},401);const r=await env.DB.prepare(`SELECT p.id,p.category,p.tag,p.title,p.body,p.created_at,COALESCE(u.display_name,'SS Desk') author FROM saves s JOIN posts p ON p.id=s.post_id LEFT JOIN users u ON u.id=p.author_id WHERE s.user_id=? ORDER BY s.created_at DESC`).bind(user.id).all();return json({posts:r.results});}
async function newsletter(request,env){const b=await body(request);const email=cleanText(b?.email,160).toLowerCase();if(!validEmail(email))return json({error:"Enter a valid email"},400);await env.DB.prepare("INSERT OR IGNORE INTO newsletter_subscribers(id,email,created_at) VALUES(?,?,?)").bind(id(),email,now()).run();return json({ok:true});}
async function admin(request,env,path){const user=await auth(request,env);if(!user||!['admin','editor'].includes(user.role))return json({error:"Admin access required"},403);if(path==="/api/admin/stats"){const [users,posts,comments,reports]=await Promise.all([env.DB.prepare("SELECT COUNT(*) n FROM users").first(),env.DB.prepare("SELECT COUNT(*) n FROM posts").first(),env.DB.prepare("SELECT COUNT(*) n FROM comments").first(),env.DB.prepare("SELECT COUNT(*) n FROM reports WHERE status='open'").first()]);return json({users:Number(users.n),posts:Number(posts.n),comments:Number(comments.n),open_reports:Number(reports.n)});}return json({error:"Admin endpoint not found"},404);}

export default {
  async fetch(request, env) {
    const url=new URL(request.url); const path=url.pathname;
    try {
      if(path.startsWith('/api/')) {
        if(path==='/api/health') return json({ok:true,service:'ss-news-api',time:now()});
        if(path==='/api/me'&&request.method==='GET') return json({user:publicUser(await auth(request,env))});
        if(path==='/api/auth/register'&&request.method==='POST') return await register(request,env);
        if(path==='/api/auth/login'&&request.method==='POST') return await login(request,env);
        if(path==='/api/auth/logout'&&request.method==='POST') return await logout(request,env);
        if(path==='/api/posts'&&request.method==='GET') return await getPosts(request,env);
        if(path==='/api/posts'&&request.method==='POST') return await createPost(request,env);
        if(path==='/api/saved'&&request.method==='GET') return await saved(request,env);
        if(path==='/api/newsletter'&&request.method==='POST') return await newsletter(request,env);
        let m=path.match(/^\/api\/posts\/([^/]+)\/(like|save|comments)$/); if(m){const [,pid,action]=m;if(action==='like'&&request.method==='POST')return await toggleLike(request,env,pid);if(action==='save'&&request.method==='POST')return await toggleSave(request,env,pid);if(action==='comments')return await comments(request,env,pid);}
        if(path.startsWith('/api/admin/'))return await admin(request,env,path);
        return json({error:'API route not found'},404);
      }
      return env.ASSETS.fetch(request);
    } catch(e) { console.error(e); return json({error:'Internal server error'},500); }
  }
};
