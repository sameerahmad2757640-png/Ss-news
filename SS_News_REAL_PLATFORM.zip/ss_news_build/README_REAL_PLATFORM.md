# SS News — real Cloudflare Worker + D1 foundation

This version converts the static SS News demo into a same-origin full-stack Worker application.

## What is now real
- D1-backed users and sessions
- Secure HttpOnly session cookie
- PBKDF2 password hashing using Cloudflare Web Crypto
- Persistent posts
- Persistent likes
- Persistent saves
- Persistent comments
- Newsletter subscriptions
- Admin/editor role checks and basic stats API
- Static frontend served by the same Worker

## Deploy
1. In Cloudflare, open the `ss-news` Worker and add a D1 binding named `DB` pointing to `ss-news-db`.
2. If using Wrangler, replace `PASTE_YOUR_D1_DATABASE_ID_HERE` in `wrangler.jsonc` with the database ID.
3. Apply the migration:
   `npx wrangler d1 migrations apply ss-news-db --remote`
4. Deploy:
   `npx wrangler deploy`

## Make the first account an admin
After registering your own account, run a D1 query in the Cloudflare dashboard SQL console:

`UPDATE users SET role='admin' WHERE email='YOUR_EMAIL_HERE';`

Do not send your password or Cloudflare API token to anyone.

## Next production modules
- R2 image upload pipeline
- Email verification / password reset
- Follow system + notifications
- Reports/moderation UI
- Admin content editor
- Dynamic sitemap/robots/JSON-LD
- Ad management and analytics
- Abuse/rate limiting and stronger account protection
